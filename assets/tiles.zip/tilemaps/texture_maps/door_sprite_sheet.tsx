<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="door_sprite_sheet" tilewidth="64" tileheight="64" tilecount="4" columns="4">
 <image source="../../tiles/door_sprite_sheet.png" width="256" height="64"/>
</tileset>
