<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="stone_sprite_sheet" tilewidth="64" tileheight="64" tilecount="3" columns="3">
 <image source="../../tiles/stone_sprite_sheet.png" width="192" height="64"/>
</tileset>
